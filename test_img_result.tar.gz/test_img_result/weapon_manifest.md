# Weapon Digitization Manifest

## CANNE
- **New filename:** `CANNE.jpg`
- **Original:** `pinterest_531284087304613244.jpg`
- **Description (OCR):**
```
CANNE
Tutti i modelli impiegano canne ad anima liscia In ferro fucinato.
La parte superiore della culatta presenta cinque facce piane disposte come una porzione di
prisma ottagonale, mentre la parte incassata e rotonda come tutto il resto della canna. Lo spessore
del metallo decresce dalla culatta verso la bocca, che é tagliata di netto senza arrotondamenti o
svasature.
La canna e ottenuta da una lastra arrotolata a caldo in modo da congiungerne i bordi. che
venivano saldati; poi veniva sgrossata, rettificata, trapanata, alesata e rifinita. Posteriormente é
chiusa da un vitone che si prolunga in una codetta la cui superficie superiore deve risultare in
allineamento con la faccia centrale della culatta. La codetta e forata per il passaggio di una vite.
| punzoni di controllo sono disposti sulle due facce oblique della culatta e l'anno di fabbricazione
é riportato sulla faccia verticale destra, davanti al foro del focone.
Solo la canna della pistola da carabinieri é in calibro 15 millimetri ed € lunga cm 12,8. Tutte le
altre sono in calibro 17 millimetri e possono essere lunghe 20 centimetri oppure 21 centimetri e
mezzo a seconda del modello di pistola al quale sono destinate. Le prime sono praticamente copie
di quelle montate sulle pistole francesi da cavalleria modello anno |X e XIll. Le seconde se ne
distinguono solo per la maggior lunghezza.
Vi possono essere delle piccole discordanze sui calibri dovute al fatto che anche le tabelle
dell'epoca prevedono, per la stessa arma, tre calibri diversi. Il primo, detto «di collaudazione», e
quello ideale (o «nominale»):; il secondo, detto «di rifiuto in fabbricazione», rappresenta il limite alla
tolleranza ammessa nell'arma nuova ed € generalmente superiore di cinque o sei decimi di
millimetro rispetto a quello ideale; il terzo, detto «di rifiuto in servizio», fornisce il limite ammesso per
usura e€ Supera il primo di almeno un millimetro. Di conseguenza l'esame eseguito su esemplari,
anche se in ottime condizioni, da risultati che non sono attendibili fino ai decimi di millimetro per
ricavarne il calibro nominale del modello al quale gli esemplari appartengono. Per questo, ove
possibile, si ¢ preferito ricorrere alle tabelle ufficiali riportando il calibro «di collaudazione».
CAVALLERIA N, >a
Mod. 1814 GUARDIE DEL CORPO DI S.M.
canna da cm 21,5
aN canna da cm. 20 ee
CAVALLERIA Mod. 1829 “a MARINERIA
bacchetta in cassa a ~~
CAVALLERIA Mod. 1829 CAVALLERIA Mod. 1833 CARABINIER!
bacchetta disgiunte
Tavola sinottica dell'impiego delle canne da cm 21,5 e da cm 20 sui modelli di pistole a pietra
focaia in uso nel Regno di Sardegna.
```

## Ikulbapyaang short sword from the Kuba and Bushoong of the
- **New filename:** `Ikulbapyaang_short_sword_from_the_Kuba_and_Bushoong_of_the.png`
- **Original:** `pinterest_531284087307565691.png`
- **Description (OCR):**
```
Ikulbapyaang short sword from the Kuba and Bushoong of the
south-west of the Democratic Republic of Congo, formerly Zaire.
```

## A Tibetan Dughti, cirea 1900
- **New filename:** `A_Tibetan_Dughti_cirea_1900.png`
- **Original:** `pinterest_531284087307609236.png`
- **Description (OCR):**
```
A Tibetan Dughti, cirea 1900.
Strong, triple-fluted single-edged blade with a brass-inlaid snake
symbol in front of the grooves. Handle with wire winding and open
worked nickel silver pommel. Leather covered wooden scabbard with
a long nickel silver mouthguard and pommel plate with stippling and
engraving.
Length 37 em.
```

## Jambeli — Short Sword
- **New filename:** `Jambeli_Short_Sword.png`
- **Original:** `pinterest_531284087307609260.png`
- **Description (OCR):**
```
Jambeli — Short Sword.
Boa / Angba / Hanga, D.R. Congo
In addition to being a functional blade,
the Mambeli short sword served as a symbol
of prestige and as currency. Most were carried
under the belt without a sheath; examples with
ire. While their dimensions vary
short sword was produced in
large quantities by the Boa (Ababua, Bobwa),
Angba (including the Mongelima), and Hanga.
They were also collected among numerous
neighboring populations, including the Bandia,
Zande, Mangbetu, Nzakara, Barambo, Mba,
Ndaaka, Bati, Binja, and Bengé. Thei
popularity and widespread distribution
resulted in innumerable local v nts
designed by neighboring peoples.
Iron, wood, vegetal fiber, copper, L.: 68.5 em
```

## Ntsakh or Fa — Grooved short sword
- **New filename:** `Ntsakh_or_Fa_Grooved_short_sword.png`
- **Original:** `pinterest_531284087307609287.png`
- **Description (OCR):**
```
Ntsakh or Fa — Grooved short sword
Fang, Gabon / Equatorial Guinea / Cameroon
his fine short sword comes from the Fang, who inhabit the rainforest
in an area that stretches over three countries. It would have originally
been carried in a sheath, called Abam, composed of two wooden
overed with stitched lizard skin from the Ornate
ly a symbol of status, these
blades were also used in a ceremonial context, and are very functional
as well, with two sharp cutting edges.
Iron, wood, L: 46 cm
```
